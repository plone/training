storage of extends for offline use
