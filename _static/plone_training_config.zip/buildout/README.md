training_buildout
=================

Buildout for the Mastering Plone Training

http://training.plone.org
